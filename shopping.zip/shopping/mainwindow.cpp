#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->username_input->setPlaceholderText("Enter username");
    ui->email_input->setPlaceholderText("Enter email");
    ui->phonenumber_input->setPlaceholderText("Enter phonenumber");
    ui->address_input->setPlaceholderText("Enter address");
    ui->password_input->setPlaceholderText("Enter password");
    ui->username_input_login->setPlaceholderText("Enter username");
    ui->password_input_login->setPlaceholderText("Enter password");
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_registerButton_clicked()
{

    ui->stackedWidget->setCurrentIndex(1);
////    database = QSqlDatabase::addDatabase("QSQLITE");
////    database.setDatabaseName("Shopping");
////    database.setUserName("root");
////    database.setPassword("");
////    database.setHostName("127.0.0.1");

//    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
//    db.setHostName("localhost");
//    db.setUserName("root");
//    db.setPassword("");
//    db.setDatabaseName("qt5");


//    if(db.isOpen()){
//        QMessageBox::information(this,"DATABASE IS CONNECTED"," SUCCESSFULLY");

//        QString username = ui->username_input->text();
//        QString email = ui->email_input->text();
//        QString address = ui->address_input->text();
//        QString phonenumber = ui->phonenumber_input->text();
//        QString password = ui->password_input->text();

//        // run the query

//        QSqlQuery qry;
//        qry.prepare("INSERT INTO users (username,email,phonenumber,password,address)"
//                    "VALUES(:username, :email,:phonenumber, :password, :address)");

//        qry.bindValue(":username",username);
//        qry.bindValue(":email",email);
//        qry.bindValue(":phonenumber",phonenumber);
//        qry.bindValue(":password",password);
//        qry.bindValue(":addess",address);

//        if(qry.exec()){
//            QMessageBox::information(this,"DATA INSERTED SUCCESSFULLY","SUCCESS");

//        }else{
//            QMessageBox::information(this,"NOT INSERTED","DATA not INSERTED SUCCESSFULLY");
//        }


//    }else{

//        QSqlError error = db.lastError();
//        qInfo() << "the error below";
//        qInfo() << error.databaseText();
//        //With this you get to know better why the connection failed
//               QMessageBox::information(this, "NO Connection", error.databaseText());
//        //if you change databaseText() by text() you get the error reported by the driver and the database

//    }

    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
      db.setHostName("127.0.0.1");
      db.setUserName("root");
      db.setPassword("");
      db.setDatabaseName("shopping");

//      if(db.open()){

          QMessageBox::information(this,"Connection","Database is connected");
          QString username = ui->username_input->text();
                  QString email = ui->email_input->text();
                  QString address = ui->address_input->text();
                  QString phonenumber = ui->phonenumber_input->text();
                  QString password = ui->password_input->text();

//                  QSqlQuery qry;
//                          qry.prepare("INSERT INTO users (username,email,phonenumber,password,address,history)"
//                                      "VALUES(:username, :email, :phonenumber, :password, :address, :history)");
//                  QSqlQuery qry;
//                          qry.prepare("INSERT INTO users (id)"
//                                      "VALUES(:id)");

//                          qry.bindValue(":id",10);
//                  QSqlQuery query;
//                      query.prepare("INSERT INTO users (id)
//                                    VALUES (?)");
//                      query.addBindValue(1001);

//                  db.setDatabaseName("testing");

                     if(!db.open()){
                         qDebug() << "Not opened";
                         QMessageBox::information(this,"NOT OPENED","DATABASE NOT OPENED");
                     }
                     qDebug() << "Opened!";

                     QSqlQuery query;

                     //CREATE the table before executing the INSERT statement
                     query.exec("CREATE TABLE users (id INTEGER, username TEXT, password TEXT,email TEXT,phonenumber TEXT,address TEXT);");

                     query.prepare("INSERT INTO users (id, username,password,email,phonenumber,address) "
                                   "VALUES (:id, :username, :password, :email,:phonenummber,:address)");
                     query.bindValue(":id", 1001);
                     query.bindValue(":username", username);
                     query.bindValue(":password", password);
                     query.bindValue(":email", email);
                     query.bindValue(":phonenumber", phonenumber);
                     query.bindValue(":address", address);

                     if( !query.exec() ){
                         QMessageBox::information(this,"Error",query.lastError().text());
                         qDebug() << query.lastError().text();
                     }
                     else{
                          QMessageBox::information(this,"DATA INSERTED","inserted suxxxxxx");
                           qDebug( "Inserted!" );
                     }



//                          qry.bindValue(":username",username);
//                          qry.bindValue(":email",email);
//                          qry.bindValue(":phonenumber",phonenumber);
//                          qry.bindValue(":password",password);
//                          qry.bindValue(":addess",address);
//                          qry.bindValue(":history","nne");

//                          if(query.exec()){
//                              QMessageBox::information(this,"DATA INSERTED SUCCESSFULLY","SUCCESS");

//                          }else{
//                              QMessageBox::information(this,"NOT INSERTED",query.lastError().text());
//                          }

//      }
//else{
//          QSqlError error = db.lastError();
//           //With this you get to know better why the connection failed
//                  QMessageBox::information(this, "Connection", error.databaseText());
//           //if you change databaseText() by text() you get the error reported by the driver and the database

//         // QMessageBox::information(this,"Connection Failed","Database is NOT connected");
//      }

}


void MainWindow::on_account_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);

}


void MainWindow::on_home_4_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

