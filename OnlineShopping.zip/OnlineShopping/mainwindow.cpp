#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setHostName("127.0.0.1");
    db.setUserName("root");
    db.setPassword("");
    db.setDatabaseName("qt5");

    if(db.open()){

        QMessageBox::information(this,"Connection","Database is connected");

    }else{
        QSqlError error = db.lastError();
         //With this you get to know better why the connection failed
                QMessageBox::information(this, "Connection", error.databaseText());
         //if you change databaseText() by text() you get the error reported by the driver and the database

       // QMessageBox::information(this,"Connection Failed","Database is NOT connected");
    }
}

